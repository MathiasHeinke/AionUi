"""Durable Command EVE delivery for Hermes ACP background completions.

Hermes already owns background-delegation execution and its durable completion
ledger.  This module only bridges a completed ledger event to an ACP client
that explicitly advertises the Command EVE v1 completion extension.  The
client remains responsible for binding the ACP session to its conversation and
for applying the resulting follow-up turn at most once, with an explicit
unknown outcome when delivery cannot be proven safely.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Callable, Iterable

logger = logging.getLogger(__name__)

# agent-client-protocol's AgentSideConnection adds the ACP extension underscore
# on the wire. Passing an already-prefixed name would send ``__command_eve``.
COMMAND_EVE_ASYNC_COMPLETION_METHOD = "command_eve/async_completion"
COMMAND_EVE_ASYNC_COMPLETION_CAPABILITY_VERSION = 1
COMMAND_EVE_ASYNC_COMPLETION_WIRE_VERSION = "command-eve-async-completion/v1"

_TERMINAL_ACCEPTED_OUTCOMES = frozenset({"accepted", "already_applied"})
_RETRYABLE_OUTCOME = "retryable"
_REJECTED_OUTCOME = "rejected"


def supports_command_eve_async_completion(client_capabilities: Any) -> bool:
    """Return true only for the exact advertised Command EVE v1 extension."""

    # agent-client-protocol 0.9 maps the wire alias ``_meta`` to the Python
    # attribute ``field_meta``.  Keep the generic fallbacks for lightweight
    # test doubles and future schema versions.
    meta = getattr(client_capabilities, "field_meta", None)
    if not isinstance(meta, dict):
        meta = getattr(client_capabilities, "meta", None)
    if not isinstance(meta, dict):
        meta = getattr(client_capabilities, "_meta", None)
    if not isinstance(meta, dict):
        return False
    command_eve = meta.get("command_eve")
    if not isinstance(command_eve, dict):
        return False
    capability = command_eve.get("async_completion")
    if not isinstance(capability, dict):
        return False
    version = capability.get("version")
    return (
        type(version) is int
        and version == COMMAND_EVE_ASYNC_COMPLETION_CAPABILITY_VERSION
    )


class CommandEveAsyncCompletionPump:
    """Claim and deliver completion events owned by loaded ACP sessions."""

    def __init__(
        self,
        *,
        connection_getter: Callable[[], Any],
        session_ids_getter: Callable[[], Iterable[str]],
        poll_interval_seconds: float = 0.5,
    ) -> None:
        self._connection_getter = connection_getter
        self._session_ids_getter = session_ids_getter
        self._poll_interval_seconds = max(0.05, poll_interval_seconds)
        self._task: asyncio.Task[None] | None = None

    @property
    def running(self) -> bool:
        return self._task is not None and not self._task.done()

    def start(self) -> None:
        if self.running:
            return
        self._task = asyncio.create_task(
            self._run(), name="command-eve-acp-async-completion"
        )

    def cancel(self) -> None:
        task = self._task
        self._task = None
        if task is not None and not task.done():
            task.cancel()

    def _loaded_session_ids(self) -> set[str]:
        return {
            str(session_id).strip()
            for session_id in self._session_ids_getter()
            if str(session_id).strip()
        }

    @staticmethod
    def _event_session_id(event: dict[str, Any], loaded: set[str]) -> str:
        routed = {
            str(event.get(key) or "").strip()
            for key in ("origin_ui_session_id", "session_key")
            if str(event.get(key) or "").strip()
        }
        if len(routed) != 1:
            return ""
        session_id = next(iter(routed))
        return session_id if session_id in loaded else ""

    def _owns_event(self, event: dict[str, Any]) -> bool:
        if event.get("type") != "async_delegation":
            return False
        return bool(self._event_session_id(event, self._loaded_session_ids()))

    @staticmethod
    def _payload(
        event: dict[str, Any], *, session_id: str, content: str
    ) -> dict[str, Any]:
        delegation_id = str(event.get("delegation_id") or "").strip()
        return {
            "version": COMMAND_EVE_ASYNC_COMPLETION_WIRE_VERSION,
            "completion_id": delegation_id,
            "session_id": session_id,
            "content": content,
        }

    @staticmethod
    def _requeue_after(
        registry: Any, event: dict[str, Any], *, busy: bool
    ) -> None:
        retries = int(event.get("_command_eve_busy_retries") or 0)
        if busy:
            retries += 1
            event["_command_eve_busy_retries"] = retries
            delay = min(30.0, float(2 ** min(retries - 1, 5)))
        else:
            delay = 2.0
        event["_command_eve_retry_at"] = time.monotonic() + delay
        registry.completion_queue.put(event)

    async def drain_once(self) -> int:
        """Attempt every currently-owned due completion once."""

        from tools import async_delegation
        from tools.process_registry import process_registry

        delivered = 0
        drained = process_registry.drain_notifications(
            owns_event=self._owns_event,
            skip_poll_observed=False,
        )
        for event, content in drained:
            retry_at = float(event.get("_command_eve_retry_at") or 0.0)
            if retry_at > time.monotonic():
                process_registry.completion_queue.put(event)
                continue

            loaded = self._loaded_session_ids()
            session_id = self._event_session_id(event, loaded)
            delegation_id = str(event.get("delegation_id") or "").strip()
            if not session_id or not delegation_id:
                process_registry.completion_queue.put(event)
                continue

            claim_id = async_delegation.claim_event_delivery(
                event, "command-eve-acp"
            )
            if claim_id is None:
                durable = async_delegation.get_durable_delegation(delegation_id)
                if durable is not None and durable.get("delivery_state") == "pending":
                    self._requeue_after(process_registry, event, busy=False)
                continue

            connection = self._connection_getter()
            if connection is None:
                async_delegation.release_event_delivery(event, claim_id)
                self._requeue_after(process_registry, event, busy=False)
                continue

            try:
                response = await connection.ext_method(
                    COMMAND_EVE_ASYNC_COMPLETION_METHOD,
                    self._payload(event, session_id=session_id, content=content),
                )
            except asyncio.CancelledError:
                async_delegation.release_event_delivery(event, claim_id)
                process_registry.completion_queue.put(event)
                raise
            except Exception:
                logger.warning(
                    "Command EVE completion delivery failed for %s",
                    delegation_id,
                    exc_info=True,
                )
                async_delegation.release_event_delivery(event, claim_id)
                self._requeue_after(process_registry, event, busy=False)
                continue

            outcome = (
                str(response.get("status") or "").strip()
                if isinstance(response, dict)
                else ""
            )
            if outcome in _TERMINAL_ACCEPTED_OUTCOMES:
                async_delegation.complete_event_delivery(event, claim_id)
                delivered += 1
            elif outcome == _RETRYABLE_OUTCOME:
                async_delegation.defer_event_delivery(event, claim_id)
                self._requeue_after(process_registry, event, busy=True)
            elif outcome == _REJECTED_OUTCOME:
                async_delegation.drop_completion_delivery(
                    delegation_id, claim_id
                )
            else:
                logger.warning(
                    "Command EVE returned an invalid completion outcome for %s",
                    delegation_id,
                )
                async_delegation.release_event_delivery(event, claim_id)
                self._requeue_after(process_registry, event, busy=False)
        return delivered

    async def _run(self) -> None:
        try:
            while True:
                await self.drain_once()
                await asyncio.sleep(self._poll_interval_seconds)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Command EVE ACP completion pump stopped unexpectedly")
